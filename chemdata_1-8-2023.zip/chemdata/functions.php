<?php
include('config.php');

function getusernamebyid($con,$id)
{
    $selectquery = "SELECT * FROM `usermaster` where `userid`='$id'";
    //  echo $selectquery;
   $result = mysqli_query($con, $selectquery);
   $row = mysqli_fetch_assoc($result);
   $legerid=$row['name'];

   echo $legerid;
}


function getchem_mechID($con,$id)
{
    $selectquery = "SELECT * FROM `chem_mechmaster` where `ChemMechId`='$id'";
   //   echo $selectquery;
   $result = mysqli_query($con, $selectquery);
   $row = mysqli_fetch_assoc($result);
   $legerid=$row['Name'];

   return $legerid;
}


function getgradenamebyID($con,$id)
{
    $selectquery = "SELECT * FROM `grademaster` where `Gradeid`='$id'";
      // echo $selectquery;
      $GradeName="No Record Found";
   $result = mysqli_query($con, $selectquery);
   $row = mysqli_fetch_assoc($result);
   $GradeName=$row['GradeName'];

   return $GradeName;
}
function getunitnamebyID($con,$id)
{
    $selectquery = "SELECT * FROM `unitmaster` where `id`='$id'";
      // echo $selectquery;
      $unitname="No Record Found";
   $result = mysqli_query($con, $selectquery);
   $row = mysqli_fetch_assoc($result);
   $unitname=$row['unit'];

   return $unitname;
}


function getgradenamebychildcode($con,$childcode)
{
    $selectquery = "SELECT * FROM `gradediameteruniquecode` where `uniquecode`='$childcode'";
      // echo $selectquery;
   $result = mysqli_query($con, $selectquery);
   $row = mysqli_fetch_assoc($result);
   $gradeid=$row['grade'];

   // $GradeName=getgradenamebyID($con,$gradeid);

   return $gradeid;
}


function getobservactiontable($con,$lotnoformasters)
{
   $rowcode= "<tr> <th>Lot No</th> <th></th> "; 
        
    
   $selectmenulist="SELECT * FROM `itemchemicalcompositionobs` where `lotno`='$lotnoformasters'";
   
   $res=mysqli_query($con,$selectmenulist);
   
   if(mysqli_num_rows($res)>0)
   {
     $num=1;
           while($row=mysqli_fetch_array($res))
       {
      
           $rowcode.="<th>".getchem_mechID($con,$row['ChemMechId'])."</th>";
            
       $num++;
     }
   }
  
   $rowcode.="</tr>";

   $minrow= "<tr> <td></td> <td>Min</td> "; 
       
   
   $selectmenulist="SELECT * FROM `itemchemicalcompositionobs` where `lotno`='$lotnoformasters'";
   
   $res=mysqli_query($con,$selectmenulist);
   
   if(mysqli_num_rows($res)>0)
   {
     $num=1;
           while($row=mysqli_fetch_array($res))
       {
      
           $minrow.="<td>".$row['MnValue']."</td>";
            
       $num++;
     }
   }
  
   $minrow.="</tr>";

   $maxrow= "<tr>  <td></td><td>Max</td> "; 
       
   
   $selectmenulist="SELECT * FROM `itemchemicalcompositionobs` where `lotno`='$lotnoformasters'";
   
   $res=mysqli_query($con,$selectmenulist);
   
   if(mysqli_num_rows($res)>0)
   {
     $num=1;
           while($row=mysqli_fetch_array($res))
       {
      
           $maxrow.="<td>".$row['MxValue']."</td>";
            
       $num++;
     }
   }
  
   $maxrow.="</tr>";

   

   $obsrow= "<tr> <td><b>".$lotnoformasters."</b></td> <td>Observed</td> "; 
       
   
   $selectmenulist="SELECT * FROM `itemchemicalcompositionobs` where `lotno`='$lotnoformasters'";
   
   $res=mysqli_query($con,$selectmenulist);
   
   if(mysqli_num_rows($res)>0)
   {
     $num=1;
           while($row=mysqli_fetch_array($res))
       {
      
           $obsrow.="<td>".$row['obsvalue']."</td>";
            
       $num++;
     }
   }
  
   $obsrow.="</tr>";




   echo $rowcode.$minrow.$maxrow.$obsrow;
}

function getgradenamebylotno($con,$lotno)
{
   $selectquery = "SELECT * FROM `reciptmaster` where `lotno`='$lotno'";
   // echo $selectquery;
   $result = mysqli_query($con, $selectquery);
   $row = mysqli_fetch_assoc($result);
   $itemchildcode=$row['itemcode'];

   return getgradenamebychildcode($con,$itemchildcode);
}


function updatejobcardno($con,$jbcid)
{
  $prefix="JBC-";
  $jobcardID=$prefix.$jbcid;
    $updatesql="UPDATE `jobcardmaster` SET `jbcno`='$jobcardID' WHERE `jobcardid`='$jbcid'";
    $result=mysqli_query($con,$updatesql);

}
function updateopenpostatustoone($con,$openpoid)
{
    $updatesql="UPDATE `openporawdata` SET `status`='1' WHERE `id`='$openpoid'";
    $result=mysqli_query($con,$updatesql);
}



function getreciptdatafortransaction($con,$reciptid)
{
  $selectquery = "SELECT * FROM `reciptmaster` where `id`='$reciptid'";
  // echo $selectquery;
  $result = mysqli_query($con, $selectquery);
  if(mysqli_num_rows($result)>0)
  {
        $row = mysqli_fetch_assoc($result);
        $date=$row['reciptdate'];
        $childcode=$row['itemcode'];
        $category=$row['category'];
        $itemdisc=$row['reciptdisc'];
        $qty=$row['qty'];
        $lotno=$row['lotno'];
        $itemunit=getunitnamebyID($con,$row['rmunitcode']);
        $itemcode=getgradenamebychildcode($con,$childcode);

        $itemname=getgradenamebyID($con,$itemcode);

      makestocktransactionentry($con,$date,$itemcode,"INWARD",$qty,$lotno);

      makestockentry($con,$itemname,$itemcode,$itemdisc,$category,"ROW",$qty,$itemunit);
  }
  else
  {
    echo " Data Not For this recipt Id".$reciptid;
  }
}

function makestocktransactionentry($con,$date,$itemcode,$transactiotype,$qty,$lotno)
{

  $selectsql="SELECT * FROM `stocktransactionmaster` WHERE `date`='$date' AND `itemcode`='$itemcode' AND `type`='$transactiotype' AND `qty`='$qty' AND `lotno`='$lotno'";

  $res=mysqli_query($con,$selectsql);

  if(mysqli_num_rows($res)>0)
  {
    echo " Transactio Record Founded";
  }else{
    $insertsql="INSERT INTO `stocktransactionmaster`(`date`, `itemcode`, `type`, `qty`, `lotno`) 
    VALUES ('$date','$itemcode','$transactiotype','$qty','$lotno')";
$result=mysqli_query($con,$insertsql);
  }

    
}



function makestockentry($con,$itemname,$itemcode,$disc,$category,$type,$qty,$unit)
{
  $checkrecordexistornotsql="SELECT * FROM `stocktable` WHERE `itemcode`='$itemcode' AND `itemcat`='$category' AND `type`='$type'";

  $rescheck=mysqli_query($con,$checkrecordexistornotsql);

  if(mysqli_num_rows($rescheck)>0)
  {
    //Update Stock
    $updateqty="UPDATE `stocktable` SET `qty`=qty+$qty WHERE `itemcode`='$itemcode'";
    mysqli_query($con,$updateqty);
    
  }else
  {
    //Create new stock Entry 
    $inserttostocksql="INSERT INTO `stocktable`(`itemcode`, `itemname`, `itemdisc`, `itemcat`, `type`, `qty`, `unit`) 
                                VALUES ('$itemcode','$itemname','$disc','$category','$type','$qty','$unit')";
      mysqli_query($con,$inserttostocksql);

  }

}

















// function generateRandomJobCardNumber($length = 6)
// {
//     $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
//     $randomString = '';
//     $charLength = strlen($characters);
//     for ($i = 0; $i < $length; $i++) {
//         $randomString .= $characters[rand(0, $charLength - 1)];
//     }
//     return $randomString;
// }



// function getuniquejobcardnumber($con)
// {
//   $jobCardNumber = generateRandomJobCardNumber();

//  // Generate a random job card number
// $jobCardNumber = generateRandomJobCardNumber();

// // Check if the number already exists in the database
// $query = "SELECT * FROM `jobcardmaster` WHERE `jbcno` = '$jobCardNumber'";
// $result = $con->query($query);

// // Keep generating new numbers until you find a unique one
// while ($result->num_rows > 0) {
//     $jobCardNumber = generateRandomJobCardNumber();
//     $query = "SELECT * FROM `jobcardmaster` WHERE `jbcno` = '$jobCardNumber'";
//     $result = $con->query($query);
// }

// // Now $jobCardNumber holds a unique number that can be used
// return $jobCardNumber;


// }
?>


