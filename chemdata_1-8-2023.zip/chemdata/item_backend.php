<?php
session_start();
include('config.php');
include('functions.php');
	extract($_POST);
	$loginuserid=$_SESSION['id'];

    //insert new Menu
    if(isset($_POST['itemcode']) && isset($_POST['disc'])&& isset($_POST['compotype'])&& 
	isset($_POST['basicmaterial'])&& isset($_POST['drawingno'])&& isset($_POST['itemlength'])&& 
	isset($_POST['itemdia'])&& isset($_POST['gweight'])&& 
	isset($_POST['nweight'])&& isset($_POST['childcode'])&& isset($_POST['unit']) )
{

    $insetitemsql="INSERT INTO `itemmaster`(`itemcode`, `disc`, `bo/ih`, `basic_material`, `drgno`, `length`, `dia`, `gweight`, `nweight`, `childcode`, `unitcode`) 
	VALUES ('$itemcode','$disc','$compotype','$basicmaterial','$drawingno','$itemlength','$itemdia','$gweight','$nweight','$childcode','$unit')";


            if(mysqli_query($con,$insetitemsql))
            {			

            $output="Done";

            }
            echo $output;
    // }

}


?>