

<?php

 $con=mysqli_connect("localhost","root","","chemdata")or die(mysqli_error($con));



 // For production

//  $con=mysqli_connect("localhost","gvsoft_root","gvsoft@2023","gvsoft_rgb_oos")or die(mysqli_error($con));

?>

